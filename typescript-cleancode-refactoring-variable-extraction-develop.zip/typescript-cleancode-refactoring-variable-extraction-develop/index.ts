import {FizzBuzz} from "./FizzBuzz";

let fizzbuzz = new FizzBuzz(15);
console.log(fizzbuzz.message)
